package com.example.demo.models;

public class AuthenticateResponse {
	private String message;
	private String token;
	public AuthenticateResponse(String message, String jwtToken) {
	this.message=message;
	this.token=jwtToken;
	}
	public String getMessage() {
		return message;
	}

	public String getToken() {
		return token;
	}
	
}
