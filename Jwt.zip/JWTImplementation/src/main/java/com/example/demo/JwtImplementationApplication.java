package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.config.MyUserDetailsService;
import com.example.demo.models.AuthenticateRequest;
import com.example.demo.models.AuthenticateResponse;
import com.example.demo.util.JwtUtil;

@SpringBootApplication
@RestController
public class JwtImplementationApplication {

	@Autowired
	AuthenticationManager authenticationManager;
	
	@Autowired
	MyUserDetailsService  myUserDetailsService;
	
	@Autowired
	JwtUtil  jwtUtil;
	
	
	@GetMapping("/user")
	public String method1() {
		return "Welcome";
	}
	@GetMapping("/verify")
	public String  method2r( @RequestHeader ("Authorization") String token) throws Exception {
		
		try {
		 jwtUtil.validateToken(token, "maddhan");
		}
		catch(Exception ex) {
			System.out.println("*********************8"+ex.getMessage());
			throw new Exception (ex.getMessage());
		}
		return token;
		
	}
	
	@PostMapping("/user" )
	public ResponseEntity<?>createAuthenticationToken(@RequestBody AuthenticateRequest authenticateRequest) throws Exception{
	
		try {
		authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(authenticateRequest.getUsername(), authenticateRequest.getPassword()));
		}
		catch (BadCredentialsException e) {
			throw new Exception("Invalid Userame or password"+e);
		}
		
		final UserDetails userDetails = myUserDetailsService.loadUserByUsername(authenticateRequest.getUsername());
		
		final String jwtToken = jwtUtil.generateToken(userDetails.getUsername());
		return ResponseEntity.ok(new AuthenticateResponse("Successfully Logined",jwtToken));
		
	}
	
	
	public static void main(String[] args) {
		SpringApplication.run(JwtImplementationApplication.class, args);
	}

}
